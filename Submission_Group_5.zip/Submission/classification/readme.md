# Readme - How to use
- You only have to setup jupyter notebook on your device
- Then open the [Solution Notebook](./data_mining_project_solution.ipynb)
- Then press run all button.